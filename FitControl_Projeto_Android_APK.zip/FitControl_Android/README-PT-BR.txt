FITCONTROL PARA ANDROID — PROJETO PARA GERAR APK

Este projeto transforma o HTML FitControl em um aplicativo Android com ícone e abertura em tela própria, usando WebView. Os dados do app continuam salvos localmente no aparelho (localStorage); não há sincronização automática.

IMPORTANTE: este pacote é o PROJETO-FONTE, não um APK pronto. Neste ambiente não há Android SDK/Gradle para compilar e testar o APK localmente. O fluxo do GitHub Actions incluído compila um APK de depuração automaticamente quando o projeto é enviado a um repositório GitHub.

COMO GERAR O APK PELO GITHUB (gratuito):
1. Entre em https://github.com e crie um repositório chamado FitControl-Android.
2. Envie todos os arquivos e pastas deste ZIP para a raiz do repositório.
3. Abra a aba Actions e habilite os workflows, se o GitHub solicitar.
4. Vá em Actions, selecione “Build FitControl APK” e clique em Run workflow (ou faça um commit para iniciar a compilação).
5. Quando a execução terminar com sucesso, abra a execução e baixe o artefato “FitControl-debug-APK”.
6. Extraia o ZIP do artefato no celular e toque no APK. O Android pode pedir autorização para instalar apps desta fonte; só prossiga se estiver usando seu próprio repositório e confiar no arquivo.

LIMITAÇÕES:
- O APK gerado pelo workflow é um APK de depuração, não assinado para publicação na Google Play.
- Algumas partes visuais carregam Tailwind CSS e ícones por internet/CDN. Por isso, a primeira abertura e alguns estilos podem exigir conexão.
- O HTML original foi mantido dentro do app; não alterei intencionalmente as regras de cálculo ou os dados de nutrição.
- Antes de distribuir, teste os recursos no seu aparelho. O app não substitui orientação médica ou nutricional.
